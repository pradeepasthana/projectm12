data <- read.csv("latest_bin_nitin1.csv",header=TRUE)
data$result <- as.factor(data$result)
set.seed(123)
ind <- sample(2,nrow(data),replace=TRUE,prob=c(0.7,0.3))
train <- data[ind==1,]
test <- data[ind==2,]
library(e1071)
library(rminer)
library(caret)
e1071model <- naiveBayes(result~.,data=train)
e1071prediction <- predict(e1071model,test)
print(confusionMatrix(e1071prediction,test$result))