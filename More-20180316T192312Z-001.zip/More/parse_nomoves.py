import re
f=open('copyfromfinal.txt','r')
s=1
for fi in iter(f):
    if re.search('[R][e][s][u][l][t] ".+"',fi):
        
        if fi.find("1/2-1/2")!=-1:
            ans=0.5
        elif fi.find("0-1")!=-1:
            ans=0
        elif fi.find("1-0")!=-1:
            ans=1
        print (ans)
    elif re.search('[W][h][i][t][e][E][l][o] ".+"',fi):
        lst=re.findall('[0-9]+',fi)
        str=lst[0]
        print(int(str))
    elif re.search('[B][l][a][c][k][E][l][o] ".+"',fi):
        lst=re.findall('[0-9]+',fi)
        str=lst[0]
        print(int(str))
    elif re.search('[E][C][O] ".+"',fi):
        lst=re.findall('[A-Z][0-9]+',fi)
        str=lst[0]
        print(str)
        
        
    
        
