import re
f=open('testing123.txt','r')
found=1
str_move=''

for fi in iter(f):
    if len(fi.strip()) == 0 :   #string is empty
        found=0
    else:
        if found==1:
            if re.search('[0-9]+[\.][ ][A-Z]?[a-z]+[0-9]',fi):
                
                index1=fi.find('{')
                move=fi[0:index1]
                str_move=str_move+move
                print (str_move)
                index2=fi.find('-')
                index3=fi.find('+')
                if index2!=-1:
                    index4=fi.find(']')
                    if index4!=-1:
                        eval_score=fi[index2:index4]
                elif index3!=-1:
                    index4=fi.find(']')
                    if index4!=-1:
                        eval_score=fi[index3:index4]
                if eval_score.find('{')!=-1:
                    eval_score='+0.20'
                    print ("yes")
                print (eval_score)
            elif re.search('[0-9][\.] [\.][\.][\.][ ][A-Z]?[a-z]+[0-9]',fi):
                index1=fi.find('{')
                if index1==-1:
                    continue
                index1=fi.find('{')
                move=fi[0:index1]
                str_move=str_move+move
                print (str_move)
                index2=fi.find('-')
                index3=fi.find('+')
                if index2!=-1:
                    index4=fi.find(']')
                    eval_score=fi[index2:index4]
                elif index3!=-1:
                    index4=fi.find(']')
                    eval_score=fi[index3:index4]
                print (eval_score)
            elif re.search('[R][e][s][u][l][t] ".+"',fi):
                if fi.find("1/2-1/2")!=-1:
                    ans=0.5
                elif fi.find("0-1")!=-1:
                    ans=0
                elif fi.find("1-0")!=-1:
                    ans=1
                print (ans)
            elif re.search('[W][h][i][t][e][E][l][o] ".+"',fi):
                lst=re.findall('[0-9]+',fi)
                str=lst[0]
                print(int(str))
            elif re.search('[B][l][a][c][k][E][l][o] ".+"',fi):
                lst=re.findall('[0-9]+',fi)
                str=lst[0]
                print(int(str))
            elif re.search('[E][C][O] ".+"',fi):
                lst=re.findall('[A-Z][0-9]+',fi)
                str=lst[0]
                print(str)
                
                    
        elif found==0:
            if fi[0:2]=='1.':
                found=1 #create new game anaylysis
                str_move=''
                index1=fi.find('{')
                move=fi[0:index1]
                str_move=str_move+move
                print (str_move)
                index2=fi.find('-')
                index3=fi.find('+')
                if index2!=-1:
                    index4=fi.find(']')
                    if index4!=-1:
                        eval_score=fi[index2:index4]
                    
                        
                elif index3!=-1:
                    index4=fi.find(']')
                if index4!=-1:
                    
                        
                    eval_score=fi[index2:index4]
                print (eval_score)
            
            elif fi[0]=='[':
                if re.search('[R][e][s][u][l][t] ".+"',fi):
        
                    if fi.find("1/2-1/2")!=-1:
                        ans=0.5
                    elif fi.find("0-1")!=-1:
                        ans=0
                    elif fi.find("1-0")!=-1:
                        ans=1
                    print (ans)
                elif re.search('[W][h][i][t][e][E][l][o] ".+"',fi):
                    lst=re.findall('[0-9]+',fi)
                    str=lst[0]
                    print(int(str))
                elif re.search('[B][l][a][c][k][E][l][o] ".+"',fi):
                    lst=re.findall('[0-9]+',fi)
                    str=lst[0]
                    print(int(str))
                elif re.search('[E][C][O] ".+"',fi):
                    lst=re.findall('[A-Z][0-9]+',fi)
                    str=lst[0]
                    print(str)
            else:
                
                found=1
                
